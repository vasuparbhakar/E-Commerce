const addressValidator = () => true;// TODO: Validation rules

// eslint-disable-next-line no-multi-assign
module.exports = exports = { addressValidator };
