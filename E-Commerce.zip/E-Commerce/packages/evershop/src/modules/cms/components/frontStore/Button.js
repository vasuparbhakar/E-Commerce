import Button from '../../../../lib/components/form/Button';
import './Button.scss';

export default Button;
