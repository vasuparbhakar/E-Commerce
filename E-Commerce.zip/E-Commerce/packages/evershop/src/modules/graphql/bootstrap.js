module.exports = () => {
  // Build schema
  require('./services/buildSchema');
}