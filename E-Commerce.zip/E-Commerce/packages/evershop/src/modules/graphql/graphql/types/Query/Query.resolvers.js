module.exports = {
  Query: {
    hello: () => 'Hello EverShop!',
  }
}
